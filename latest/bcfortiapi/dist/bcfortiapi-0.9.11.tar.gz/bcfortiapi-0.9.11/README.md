# bcfortiapi

A Python library for interacting with the Fortinet FortiGate and FortiManager APIs

## Current Status

- Status: Beta
- Latest Release: 0.9.11
- Release Date: 03-07-2026

## Dependencies

- Python 3: minimum supported version 3.11
- urllib3: minimum supported version 2.2.1
- requests: minimum supported version 2.32.3

## Usage Examples

### Initialisation

To initialise the library within your project add the following:

**FortiGate**

```
import bcfortiapi

init_variable = bcfortiapi.fgtapi(fortigate="FGT IP or FQDN", port="FGT HTTPS Admin Port", authtoken="FGT API Token", version="FortiOS Version (M.m)", debug=True/False, logfile="Full path and filename for log file", session_options={Dictionary of optional Requests session parameters})
```
- fortigate (str) = IP address or FQDN of the target FortiGate
- port (str) = HTTPS admin port number of the target FortiGate
- authtoken (str) = FortiGate API administrator token (if using basic authentication, leave this field blank and use the *login* and *logout* functions instead)
- version (str) = Major and minor FortiOS version of the target FortiGate (eg. 7.4)
- debug (bool) = Console debug output enabled
- logfile (str) = Full path and filename for log file (ie. c:\example directory\logfile.txt), if not provided file logging of debug output is disabled, requires console debug to be enabled
- session_options (dict) = {
        "session_verify": True/False/"Path to CA certificate file, bundle or directory" (default=False),
        "local_cert": "Path to client certificate file",
        "proxies": {Dictionary containing proxy servers - see Requests documentation for details}
    }

**FortiManager**

```
import bcfortiapi

init_variable = bcfortiapi.fmgapi(server="FMG IP or FQDN", port="FMG HTTPS Admin Port", version="Configuration Database Version (M.m)", debug=True/False, logfile="Full path and filename for log file", session_options={Dictionary of optional Requests session parameters})
```
- server (str) = IP address or FQDN of the target FortiManager
- port (str) = HTTPS admin port number of the target FortiManager
- version (str) = Major and minor configuration database version of the target FortiManager (eg. 7.4)
- debug (bool) = Console debug output enabled
- logfile (str) = Full path and filename for log file (ie. c:\example directory\logfile.txt), if not provided file logging of debug output is disabled, requires console debug to be enabled
- session_options (dict) = {
        "session_verify": True/False/"Path to CA certificate file, bundle or directory" (default=False),
        "local_cert": "Path to client certificate file",
        "proxies": {Dictionary containing proxy servers - see Requests documentation for details}
    }

**Tools**

```
import bcfortiapi

init_variable = bcfortiapi.toolbox(debug=True/False)
```
- debug (bool) = Console debug output enabled

### General Usage

**FortiGate**

*Login (Basic Authentication Only)*
```
init_variable.login(username="Username", password="Password")
```
    
*Login and return login state (bool)*
```
response_variable = init_variable.login(username="Username", password="Password")
```

*Example GET*
```
response_variable = init_variable.dvmdb_device(adom="ADOM name", method="get")
```

*Example GET (with URL options)*
```
response_variable = init_variable.dvmdb_device(adom="ADOM name", method="get", urloptions="vdom=root&search=string")
```

*Logout (Basic Authentication Only)*
```
init_variable.logout()
```

**FortiManager**

*Login*
```
init_variable.login(username="Username", password="Password")
```

*Login and return login state (bool)*
```
response_variable = init_variable.login(username="Username", password="Password")
```

*Example GET*
```
response_variable = init_variable.dvmdb_device(adom="ADOM name", method="get")
```

*Logout*
```
init_variable.logout()
```

## Change Log 0.9.11

- 03-07-2026: Updated Device Manager and Task Database functions to include options in GET requests (required to retrieve some data subsets such as object members)

## Change Log 0.9.10

- 12-06-2026: Fixed bug in bcfortiapi.fmgapi where "fields" list object was incorrectly enclosed in another list by the payload builder
- 12-06-2026: Updated default version value to "7.6" in bcfortiapi.fgtapi and bcfortiapi.fmgapi

## Change Log 0.9.9

- 30-05-2026: Session verification, client certificates and HTTP/HTTPS proxy servers can now be specified when initialising bcfortiapi.fgtapi and bcfortiapi.fmgapi
- 30-05-2026: Updated file logging in bcfortiapi.fgtapi and bcfortiapi.fmgapi to redact passwords included within the request body

## Change Log 0.9.8

- 23-05-2026: Added function to bcfortiapi.fgtapi and bcfortiapi.fmgapi to write debug output to a text file (filename and path specified when initialising module, requires debug mode to be enabled)

## Change Log 0.9.7

- 19-05-2026: Added support for device group management to bcfortiapi.fmgapi
- 19-05-2026: Updated bcfortiapi.fmgapi.dvmdb_device function to support specifying device name in query

## Change Log 0.9.6

- 22-03-2026: Added support to bcfortiapi.fmgapi for FortiManager 7.6 API endpoints
- 22-03-2026: Added FortiGate JSON to FortiOS CLI script tool to bcfortiapi.toolbox

## Change Log 0.9.5

- 25-02-2026: Fixed bug in Toolbox module where some debugging console output was turned on regardless of debug setting
- 24-02-2026: Added bcfortiapi.toolbox module, contains miscellaneous additional tools for use with FortiGate and FortiManager modules

## Change Log 0.9.4

- 15-02-2026: Added JSON validity check to API responses, library now returns a Python dictionary for valid JSON responses or the raw response content for non-JSON responses (such as configuration backups)
- 15-02-2026: Added bcfortiapi_test.py test program, available in source code under /tests
- 15-02-2026: Updated README.md

## Change Log 0.9.2

- 10-02-2026: Added support to bcfortiapi.fgtapi for FortiOS 7.6 API endpoints

## Change Log 0.9.1

- 09-02-2026: Removed some pre-processing of API responses, library now returns raw response content as string for external processing as required (can still be processed with json.loads)

## Change Log 0.9

- 06-02-2026: Fixed bug where JSON response containing boolean values could not be read by Python JSON module due to capitalised True/False values in response
- 06-02-2026: 0.9 Initial release

## Change Log 0.8

- 04-02-2026: 0.8 Initial release
